"""
Create a new chat group.
Add the following bots to the chat.
Constant variables.
    - TELEGRAM_BOT_API_KEY: Message (@BotFather). Create your Bot, 
        and get your Bot API key by creating a bot on Telegram .
    - CHAT_ID: Add (@RawDataBot) to your group and type: "/start" to get the chat id. 
        REF: https://www.alphr.com/find-chat-id-telegram/
"""

TELEGRAM_BOT_API_KEY = "5749871533:AAGK0vMxRn8K9fdFmrVcBsCKLoP45WdYKcw"
CHAT_ID = -776499304
DATA_DIR = "data"
DATA_FILE_NAME = "data.csv"
