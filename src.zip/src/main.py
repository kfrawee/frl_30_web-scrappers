"""
Main logic
"""
